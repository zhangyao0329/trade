// Package internal contains some helpers.
package internal
