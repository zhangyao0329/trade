## NSign

签名及签名验证，主要用于网络请求参数签名和签名验证。

## 安装

```bash
$ go get github.com/smartwalle/nsign
```

## 使用

参考 test 文件