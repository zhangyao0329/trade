package e

// 业务状态码
const (
	Success      = 1
	Error        = 0
	TokenExpired = 2
)
